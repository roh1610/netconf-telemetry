package com.telemetry.netconf.config;
import org.springframework.context.annotation.Configuration;

@Configuration
public class NetconfConfig {
    // Basic config holder
}

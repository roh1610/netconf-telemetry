package com.telemetry.netconf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetconfTelemetryApplication {
    public static void main(String[] args) {
        SpringApplication.run(NetconfTelemetryApplication.class, args);
    }
}